<div class="form-group<?php echo e($errors->has('nombre') ? ' has-error' : ''); ?>">
    <?php echo Form::label('nombre', 'Nombre', ['class' => 'col-md-4 control-label']); ?>


    <div class="col-md-6">
        <?php echo Form::text('nombre', old('nombre'), ['class' => 'form-control', 'placeholder'=>'Nombre', 'autofocus']); ?>

    </div>
</div>

<div class="form-group<?php echo e($errors->has('apellido') ? ' has-error' : ''); ?>">
    <?php echo Form::label('apellido', 'Apellido', ['class' => 'col-md-4 control-label']); ?>


    <div class="col-md-6">
        <?php echo Form::text('apellido', old('apellido'), ['class' => 'form-control', 'placeholder'=>'Apellido', 'autofocus']); ?>

    </div>
</div>

<div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
    <?php echo Form::label('email', 'E-Mail', ['class' => 'col-md-4 control-label']); ?>


    <div class="col-md-6">
        <?php echo Form::text('email', old('email'), ['class' => 'form-control', 'placeholder'=>'E-Mail', 'autofocus']); ?>

    </div>
</div>

<div class="form-group<?php echo e($errors->has('cedula') ? ' has-error' : ''); ?>">
    <?php echo Form::label('cedula', 'Cédula', ['class' => 'col-md-4 control-label']); ?>


    <div class="col-md-6">
        <?php echo Form::text('cedula', old('cedula'), ['class' => 'form-control', 'placeholder'=>'Cédula', 'autofocus']); ?>

    </div>
</div>

<div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
    <?php echo Form::label('password', 'Contraseña', ['class' => 'col-md-4 control-label']); ?>


    <div class="col-md-6">
        <?php echo Form::text('password', old('password'), ['class' => 'form-control', 'placeholder'=>'Contraseña', 'autofocus']); ?>

    </div>
</div>

<div class="form-group<?php echo e($errors->has('password_confirmation') ? ' has-error' : ''); ?>">
    <?php echo Form::label('password_confirmation', 'Confirmar contraseña', ['class' => 'col-md-4 control-label']); ?>


    <div class="col-md-6">
        <?php echo Form::text('password_confirmation', old('password_confirmation'), ['class' => 'form-control', 'placeholder'=>'Confirmar contraseña', 'autofocus']); ?>

    </div>
</div>

<div class="form-group<?php echo e($errors->has('fecha_nacimiento') ? ' has-error' : ''); ?>">
    <?php echo Form::label('fecha_nacimiento', 'Fecha de nacimiento', ['class' => 'col-md-4 control-label']); ?>


    <div class="col-md-6">
        <?php echo Form::text('fecha_nacimiento', old('fecha_nacimiento'), ['id' => 'datepicker', 'class' => 'form-control',                                                                    'placeholder'=>'dd/mm/aaaa', 'autofocus', 'readonly']); ?>

    </div>
</div>

<div class="form-group<?php echo e($errors->has('telefono') ? ' has-error' : ''); ?>">
    <?php echo Form::label('telefono', 'Teléfono', ['class' => 'col-md-4 control-label']); ?>


    <div class="col-md-6">
        <?php echo Form::text('telefono', old('telefono'), ['class' => 'form-control', 'placeholder'=> 'Teléfono', 'autofocus']); ?>

    </div>
</div>

<div class="form-group<?php echo e($errors->has('estado') ? ' has-error' : ''); ?>">
    <?php echo Form::label('estado', 'Estado', ['class' => 'col-md-4 control-label']); ?>


    <div class="col-md-6">
        <?php echo Form::select('estado', $estados, null, ['class' => 'form-control col-md-6']); ?>

    </div>
</div>

<div class="form-group<?php echo e($errors->has('direccion') ? ' has-error' : ''); ?>">
    <?php echo Form::label('direccion', 'Dirección', ['class' => 'col-md-4 control-label']); ?>


    <div class="col-md-6">
        <?php echo Form::text('direccion', old('direccion'), ['class' => 'form-control', 'placeholder'=> 'Dirección', 'autofocus']); ?>

    </div>
</div>

<div class="form-group<?php echo e($errors->has('twitter') ? ' has-error' : ''); ?>">
    <?php echo Form::label('twitter', 'Twitter', ['class' => 'col-md-4 control-label']); ?>


    <div class="col-md-6">
        <?php echo Form::text('twitter', old('twitter'), ['class' => 'form-control', 'placeholder'=> 'Twitter', 'autofocus']); ?>

    </div>
</div>

<div class="form-group<?php echo e($errors->has('instagram') ? ' has-error' : ''); ?>">
    <?php echo Form::label('instagram', 'Instagram', ['class' => 'col-md-4 control-label']); ?>


    <div class="col-md-6">
        <?php echo Form::text('instagram', old('instagram'), ['class' => 'form-control', 'placeholder'=> 'Instagram', 'autofocus']); ?>

    </div>
</div>

<div class="form-group<?php echo e($errors->has('talla') ? ' has-error' : ''); ?>">
    <?php echo Form::label('talla', 'Talla', ['class' => 'col-md-4 control-label']); ?>


    <div class="col-md-6">
        <?php echo Form::select('talla', $tallas, null, ['class' => 'form-control col-md-6']); ?>

    </div>
</div>

<div class="form-group<?php echo e($errors->has('categoria') ? ' has-error' : ''); ?>">
    <?php echo Form::label('categoria', 'Categoría', ['class' => 'col-md-4 control-label']); ?>


    <div class="col-md-6">
        <?php echo Form::select('categoria', $categorias, null, ['class' => 'form-control col-md-6']); ?>

    </div>
</div>

<div class="form-group<?php echo e($errors->has('academia') ? ' has-error' : ''); ?>">
    <?php echo Form::label('academia', 'Estudiante/Profesional (en curso o graduado)', ['class' => 'col-md-4 control-label']); ?>


    <div class="col-md-6">
        <?php echo Form::select('academia', $academias, null, ['class' => 'form-control col-md-6']); ?>

    </div>
</div>

<div class="form-group<?php echo e($errors->has('tipo') ? ' has-error' : ''); ?>">
    <?php echo Form::label('tipo', 'Estudiante/Profesional (en curso o graduado)', ['class' => 'col-md-4 control-label']); ?>


    <div class="col-md-6">
        <?php echo Form::select('tipo', $tipos, null, ['class' => 'form-control col-md-6']); ?>

    </div>
</div>